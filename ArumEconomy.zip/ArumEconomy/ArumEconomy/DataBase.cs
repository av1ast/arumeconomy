﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using ArumEconomy.Types;
using I18N;
using I18N.West;
using MySql.Data.MySqlClient;
using Rocket.Unturned.Player;

namespace ArumEconomy
{
    public class DataBase
    {
        public delegate void UpdateBalance(UnturnedPlayer player, char type, decimal sum);
        public event UpdateBalance OnUpdateBalance;
        public DataBase()
        {
            Setup();
        }
        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(string.Format("SERVER={0};PORT={1};UID={2};PASSWORD={3};DATABASE={4};charset=utf8",
                Plugin.Instance.Configuration.Instance.MySqlSettings.Host,
                Plugin.Instance.Configuration.Instance.MySqlSettings.Port,
                Plugin.Instance.Configuration.Instance.MySqlSettings.UserName,
                Plugin.Instance.Configuration.Instance.MySqlSettings.Password,
                Plugin.Instance.Configuration.Instance.MySqlSettings.DataBase
                ));
        }
        private void Setup()
        {
            try
            {
                string TablePlayers = string.Concat(new string[]
                {
                    $"CREATE TABLE IF NOT EXISTS {Plugin.Instance.Configuration.Instance.MySqlSettings.TablePlayers}",
                    "(Id int(12) not null auto_increment,",
                    "SteamID64 varchar(32) not null,",
                    "Balance decimal(12) not null,",
                    "LastUpdate varchar(32) not null,",
                    "PRIMARY KEY (`Id`))"
                });

                string TableItems = string.Concat(new string[]
                {
                    $"CREATE TABLE IF NOT EXISTS {Plugin.Instance.Configuration.Instance.MySqlSettings.TableItems}",
                    "(ItemID int(12) not null,",
                    "ItemName varchar(255) not null,",
                    "Cost decimal(10) not null,",
                    "BuyBack decimal(10) not null,",
                    "PRIMARY KEY (`ItemID`))"
                });

                string TableVehicles = string.Concat(new string[]
                {
                    $"CREATE TABLE IF NOT EXISTS {Plugin.Instance.Configuration.Instance.MySqlSettings.TableVehicles}",
                    "(VehicleID int(12) not null,",
                    "VehicleName varchar(255) not null,",
                    "Cost decimal(10) not null,",
                    "PRIMARY KEY (`VehicleID`))"
                });

                MySqlConnection connection = GetConnection();

                MySqlCommand command = new MySqlCommand(TablePlayers, connection);

                connection.Open();

                command.ExecuteNonQuery();
                //
                command.CommandText = TableItems;
                command.ExecuteNonQuery();
                //
                command.CommandText = TableVehicles;
                command.ExecuteNonQuery();

                connection.Close();
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex, "Exception in Startup"); }
        }

        public object GetObjectShop<T>(object ID)
        {
            try
            {
                string Table = "";
                string Parameter = "";
                if (typeof(T) == typeof(ItemShop)) { Table = Plugin.Instance.Configuration.Instance.MySqlSettings.TableItems; Parameter = "ItemID"; }
                if (typeof(T) == typeof(VehicleShop)) { Table = Plugin.Instance.Configuration.Instance.MySqlSettings.TableVehicles; Parameter = "VehicleID"; }
                if (typeof(T) == typeof(PlayerShop)) { Table = Plugin.Instance.Configuration.Instance.MySqlSettings.TablePlayers; Parameter = "SteamID64"; }

                string query = $"SELECT * FROM {Table} WHERE {Parameter} = @ID";

                MySqlConnection connection = GetConnection();

                connection.Open();

                MySqlCommand command = new MySqlCommand(query, connection);

                command.Parameters.AddWithValue("@ID", ID);

                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if (typeof(T) == typeof(ItemShop))
                        {
                            ItemShop itemShop = new ItemShop(ushort.Parse(reader[0].ToString()), reader[1].ToString(), decimal.Parse(reader[2].ToString()), decimal.Parse(reader[3].ToString()));
                            connection.Close();
                            return itemShop;
                        }
                        if (typeof(T) == typeof(VehicleShop))
                        {
                            VehicleShop vehicleShop = new VehicleShop(ushort.Parse(reader[0].ToString()), reader[1].ToString(), decimal.Parse(reader[2].ToString()));
                            connection.Close();
                            return vehicleShop;
                        }
                        PlayerShop playerShop = new PlayerShop(reader[1].ToString(), decimal.Parse(reader[2].ToString()), DateTime.Parse(reader[3].ToString()));
                        connection.Close();
                        return playerShop;
                    }
                }
                connection.Close();
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex, "Exception in GetObjectShop<T>"); }
            return null;
        }

        public void UpdatePlayer(UnturnedPlayer player)
        {
            try
            {
                string query = string.Concat(new string[]
                {
                    $"UPDATE {Plugin.Instance.Configuration.Instance.MySqlSettings.TablePlayers} SET ",
                    $"LastUpdate = @LastUpdate ",
                    $"WHERE SteamID64 = @SteamID64"
                });

                MySqlConnection connection = GetConnection();

                MySqlCommand command = new MySqlCommand(query, connection);

                connection.Open();

                command.Parameters.AddWithValue("@LastUpdate", DateTime.Now.ToString());
                command.Parameters.AddWithValue("@SteamID64", player.CSteamID.ToString());

                command.ExecuteNonQuery();

                connection.Close();
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex, "Exception in UpdateObjectShop"); }
        }

        public void SetBalance(UnturnedPlayer player, decimal sum, bool decrement = false)
        {
            try
            {
                string query = string.Concat(new string[]
                {
                    $"UPDATE {Plugin.Instance.Configuration.Instance.MySqlSettings.TablePlayers} SET ",
                    $"Balance = Balance + @Balance ".Replace("+", decrement == true ? "-" : "+"),
                    $"WHERE SteamID64 = @SteamID64"
                });

                if (decrement) query = query.Replace("+", "-");

                MySqlConnection connection = GetConnection();

                MySqlCommand command = new MySqlCommand(query, connection);

                connection.Open();

                command.Parameters.AddWithValue("@Balance", Math.Round(sum, 2));
                command.Parameters.AddWithValue("@SteamID64", player.CSteamID.ToString());

                command.ExecuteNonQuery();

                connection.Close();

                OnUpdateBalance?.Invoke(player, decrement ? '-' : '+', Math.Round(sum, 2));
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex, "Exception in SetBalance"); }
        }
        public void DeleteObject<T>(T obj)
        {
            try
            {
                string query = "";

                if (typeof(T) == typeof(ItemShop))
                {
                    var itemShop = (ItemShop)Convert.ChangeType(obj, typeof(ItemShop));

                    query = $"delete from {Plugin.Instance.Configuration.Instance.MySqlSettings.TableItems} where `ItemID` = '{itemShop.ItemID}'";
                }
                else
                {
                    var vehicleShop = (VehicleShop)Convert.ChangeType(obj, typeof(VehicleShop));

                    query = $"delete from {Plugin.Instance.Configuration.Instance.MySqlSettings.TableVehicles} where `VehicleID` = '{vehicleShop.VehicleID}'";
                }

                var connection = GetConnection();

                var command = new MySqlCommand(query, connection);

                connection.Open();

                command.ExecuteNonQuery();

                connection.Close();
            }
            catch (Exception ex)
            {
                Rocket.Core.Logging.Logger.LogException(ex, "Exception in DeleteObject()");
            }
        }

        public void AddObject<T>(T obj)
        {
            try
            {
                string query = "";
                if (typeof(T) == typeof(PlayerShop))
                {
                    PlayerShop player = (PlayerShop)Convert.ChangeType(obj, typeof(PlayerShop));
                    query = string.Concat(new string[]
                    {
                        $"INSERT INTO {Plugin.Instance.Configuration.Instance.MySqlSettings.TablePlayers} ",
                        "(SteamID64, Balance, LastUpdate) VALUES ",
                        $"('{player.SteamID64}', '{player.Balance}', '{player.LastUpdate}')"
                    });
                }

                if (typeof(T) == typeof(ItemShop))
                {
                    ItemShop item = (ItemShop)Convert.ChangeType(obj, typeof(ItemShop));
                    query = string.Concat(new string[]
                    {
                        $"INSERT INTO {Plugin.Instance.Configuration.Instance.MySqlSettings.TableItems} ",
                        "(ItemID, ItemName, Cost, BuyBack) VALUES ",
                        $"('{item.ItemID}', '{item.Name}', '{item.Cost}', '{item.BuyBack}') on duplicate key update ItemName = '{item.Name}', Cost = '{item.Cost}', BuyBack = '{item.BuyBack}'"
                    });
                }

                if (typeof(T) == typeof(VehicleShop))
                {
                    VehicleShop vehicle = (VehicleShop)Convert.ChangeType(obj, typeof(VehicleShop));
                    query = string.Concat(new string[]
                    {
                        $"INSERT INTO {Plugin.Instance.Configuration.Instance.MySqlSettings.TableVehicles} ",
                        "(VehicleID, VehicleName, Cost) VALUES ",
                        $"('{vehicle.VehicleID}', '{vehicle.Name}', '{vehicle.Cost}') on duplicate key update VehicleName = '{vehicle.Name}', Cost = '{vehicle.Cost}'"
                    });
                }

                MySqlConnection connection = GetConnection();

                MySqlCommand command = new MySqlCommand(query, connection);

                connection.Open();

                command.ExecuteNonQuery();

                connection.Close();
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex, "Exception in AddObject"); }
        }

        public void Dump(string path)
        {
            XmlDocument document = new XmlDocument();
            document.Load(path);
            foreach (object obj in document.DocumentElement.ChildNodes)
            {
                XmlNode node = (XmlNode)obj;
                if (node.Name == "Item")
                {
                    ItemShop item = new ItemShop(
                        ushort.Parse(node.Attributes.GetNamedItem("ItemID").Value),
                        node.Attributes.GetNamedItem("ItemName").Value,
                        decimal.Parse(node.Attributes.GetNamedItem("Cost").Value),
                        decimal.Parse(node.Attributes.GetNamedItem("BuyBack").Value)
                        );
                    AddObject(item);
                }
                if (node.Name == "Vehicle")
                {
                    VehicleShop vehicle = new VehicleShop(
                        ushort.Parse(node.Attributes.GetNamedItem("VehicleID").Value),
                        node.Attributes.GetNamedItem("VehicleName").Value,
                        decimal.Parse(node.Attributes.GetNamedItem("Cost").Value)
                        );
                    AddObject(vehicle);
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Chat;
using ArumEconomy.Types;
using UnityEngine;
using Rocket.Unturned.Player;
using Rocket.Unturned.Items;
using SDG.Unturned;

namespace ArumEconomy.Commands
{
    class CommandBuy : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;

        public string Name => "buy";

        public string Help => "";

        public string Syntax => "/buy [Item] [Amount]";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.buy" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;
            if (command.Length > 2)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            if (command.Length == 0)
            {
                player.SendUIPanel(ETypePanel.Buy);
                return;
            }

            ushort ItemID = 0;
            byte Amount = 1;

            if (command.Length >= 1)
            {
                if (!ushort.TryParse(command[0], out ItemID))
                {
                    ItemAsset itemAsset = UnturnedItems.GetItemAssetByName(command[0]);
                    if (itemAsset != null) ItemID = itemAsset.id;
                }
            }

            if (command.Length == 2)
            {
                if (!byte.TryParse(command[1], out Amount) || Amount == 0)
                {
                    UnturnedChat.Say(player, Plugin.Instance.Translate("incorrect_amount"), Color.red);
                    return;
                }
            }
            player.BuyItem(ItemID, Amount);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArumEconomy.Types;
using Rocket.API;
using Rocket.Unturned.Chat;
using Rocket.Unturned.Player;
using UnityEngine;

namespace ArumEconomy.Commands
{
    class CommandBalance : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;

        public string Name => "balance";

        public string Help => "";

        public string Syntax => "Just only /balance";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.balance" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;
            if (command.Length != 0)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            PlayerShop playerShop = (PlayerShop)Plugin.DataBase.GetObjectShop<PlayerShop>(player.CSteamID.ToString());
            UnturnedChat.Say(player, Plugin.Instance.Translate("balance", playerShop.Balance, Plugin.Instance.Configuration.Instance.NameEconomy), Color.yellow);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Player;
using Rocket.Unturned.Chat;
using UnityEngine;
using ArumEconomy.Components;
using ArumEconomy.Types;

namespace ArumEconomy.Commands
{
    class CommandSell : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;

        public string Name => "sell";

        public string Help => "";

        public string Syntax => "Just only /sell";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.sell" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;

            if (command.Length != 0)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            SellSettings sellSettings = player.GetSellSettings();

            if (sellSettings == null) throw new Exception("Missing sellSettings for this player group");

            if (player.IsInVehicle && player.CurrentVehicle.checkDriver(player.CSteamID))
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("cant_because_you_in_the_car"), Color.red);
                return;
            }

            SellComponent sellComponent = player.GetComponent<SellComponent>();
            sellComponent.Seller = new StorageSell(player, sellSettings.Height, sellSettings.Width);
            sellComponent.Seller.SendStorage();
        }
    }
}

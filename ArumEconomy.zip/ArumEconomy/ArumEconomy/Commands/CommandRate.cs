﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Chat;
using ArumEconomy.Types;
using UnityEngine;
using Rocket.Unturned.Player;
using Rocket.Unturned.Items;
using SDG.Unturned;

namespace ArumEconomy.Commands
{
    class CommandRate : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;

        public string Name => "rate";

        public string Help => "";

        public string Syntax => "/rate <sum>";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.rate" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;
            if (command.Length != 1)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            if (!decimal.TryParse(command[0], out decimal sum) || sum < 1)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("incorrect_sum"), Color.red);
                return;
            }

            PlayerShop playerShop = (PlayerShop)Plugin.DataBase.GetObjectShop<PlayerShop>(player.CSteamID.ToString());

            if (playerShop.Balance < sum)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("dont_have_money"), Color.red);
                return;
            }

            System.Random random = new System.Random();

            if (random.Next(0, 3) == 1)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("you_win", System.Math.Round(sum * 2, 2), Plugin.Instance.Configuration.Instance.NameEconomy), Color.yellow);
                Plugin.DataBase.SetBalance(player, sum);
                return;
            }
            Plugin.DataBase.SetBalance(player, sum, true);
            UnturnedChat.Say(player, Plugin.Instance.Translate("you_lose"), Color.yellow);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Player;
using Rocket.Unturned.Chat;
using UnityEngine;
using ArumEconomy.Components;

namespace ArumEconomy.Commands
{
    class CommandShowBalance : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;

        public string Name => "showbalance";

        public string Help => "";

        public string Syntax => "Just only /showbalance or /sbalance or /sb";

        public List<string> Aliases => new List<string> { "sbalance", "sb" };

        public List<string> Permissions => new List<string> { "command.showbalance", "command.sbalance", "command.sb" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;
            if (command.Length != 0)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            ShopComponent shopComponent = player.GetComponent<ShopComponent>();

            if (shopComponent.EnabledUI)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("disabled_ui_balance"), Color.yellow);
                shopComponent.EnabledUI = false;
                player.CloseUIBalance();
                return;
            }
            UnturnedChat.Say(player, Plugin.Instance.Translate("enabled_ui_balance"), Color.yellow);
            shopComponent.EnabledUI = true;
            player.SendUIBalance();
        }
    }
}

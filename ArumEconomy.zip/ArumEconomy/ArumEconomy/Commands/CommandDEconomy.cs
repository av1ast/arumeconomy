﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Chat;

namespace ArumEconomy.Commands
{
    class CommandDEconomy : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Both;

        public string Name => "deconomy";

        public string Help => "";

        public string Syntax => "/deconomy <path>";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.deconomy" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            if (command.Length != 1)
            {
                UnturnedChat.Say(caller, Plugin.Instance.Translate("syntax", Syntax));
                return;
            }

            if (!File.Exists(command[0]))
            {
                UnturnedChat.Say(caller, "File not found");
                return;
            }

            UnturnedChat.Say(caller, "Successfuly dump!");
            Plugin.DataBase.Dump(command[0]);
        }
    }
}

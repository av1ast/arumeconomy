﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Chat;
using ArumEconomy.Types;
using UnityEngine;
using Rocket.Unturned.Player;

namespace ArumEconomy.Commands
{
    class CommandSetBalance : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Both;

        public string Name => "setbalance";

        public string Help => "";

        public string Syntax => "/setbalance <player> <sum>";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.setbalance" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            if (command.Length != 2)
            {
                UnturnedChat.Say(caller, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            UnturnedPlayer otherPlayer = UnturnedPlayer.FromName(command[0]);

            if (otherPlayer == null)
            {
                UnturnedChat.Say(caller, Plugin.Instance.Translate("player_not_found"), Color.red);
                return;
            }

            if (!decimal.TryParse(command[1], out decimal sum) || sum == 0)
            {
                UnturnedChat.Say(caller, Plugin.Instance.Translate("incorrect_sum"), Color.red);
                return;
            }

            UnturnedChat.Say(caller, Plugin.Instance.Translate("set_balance", otherPlayer.DisplayName, sum, Plugin.Instance.Configuration.Instance.NameEconomy), Color.yellow);
            Plugin.DataBase.SetBalance(otherPlayer, sum);
        }
    }
}

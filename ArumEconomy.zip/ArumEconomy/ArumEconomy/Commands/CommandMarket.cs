﻿using ArumEconomy.Types;
using Rocket.API;
using Rocket.Unturned.Chat;
using SDG.Unturned;
using System.Collections.Generic;
using UnityEngine;

namespace ArumEconomy.Commands
{
    class CommandMarket : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Both;

        public string Name => "market";

        public string Help => "";

        public string Syntax => "/market <add | remove> <i | v> <itemId | vehicleId> <cost> <buyback>";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.market" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            if (command.Length < 3 || command.Length > 5 || command[0].ToLower() != "add" && command[0].ToLower() != "remove" || command[1].ToLower() != "i" && command[1].ToLower() != "v")
            {
                UnturnedChat.Say(caller, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            if (!ushort.TryParse(command[2], out ushort id))
            {
                UnturnedChat.Say(caller, Plugin.Instance.Translate("incorrect_id"), Color.red);
                return;
            }

            if (command[0].ToLower() == "remove" && command.Length > 3)
            {
                UnturnedChat.Say(caller, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            if (command[0].ToLower() == "remove")
            { 
                if (command[1].ToLower() == "i")
                {
                    var itemShop = (ItemShop)Plugin.DataBase.GetObjectShop<ItemShop>(id);

                    if (itemShop == null)
                    {
                        UnturnedChat.Say(caller, Plugin.Instance.Translate("itemshop_null"), Color.red);
                        return;
                    }

                    Plugin.DataBase.DeleteObject(itemShop);

                    UnturnedChat.Say(caller, Plugin.Instance.Translate("delete_itemshop", itemShop.ItemID, itemShop.Name), Color.yellow);

                    return;
                }

                var vehicleShop = (VehicleShop)Plugin.DataBase.GetObjectShop<VehicleShop>(id);

                if (vehicleShop == null)
                {
                    UnturnedChat.Say(caller, Plugin.Instance.Translate("vehicleshop_null"), Color.red);
                    return;
                }

                Plugin.DataBase.DeleteObject(vehicleShop);

                UnturnedChat.Say(caller, Plugin.Instance.Translate("delete_vehicleshop", vehicleShop.VehicleID, vehicleShop.Name), Color.yellow);
            }
            else
            {
                if (command.Length < 4)
                {
                    UnturnedChat.Say(caller, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                    return;
                }

                if (!decimal.TryParse(command[3], out decimal cost))
                {
                    UnturnedChat.Say(caller, Plugin.Instance.Translate("incorrect_cost"), Color.red);
                    return;
                }

                decimal buyback = 0;

                if (command.Length == 5)
                    if (!decimal.TryParse(command[4], out buyback))
                    {
                        UnturnedChat.Say(caller, Plugin.Instance.Translate("incorrect_buyback"), Color.red);
                        return;
                    }

                if (command[1].ToLower() == "i")
                {
                    var asset = Assets.find(EAssetType.ITEM, id);

                    if (asset == null)
                    {
                        UnturnedChat.Say(caller, Plugin.Instance.Translate("item_asset_null"), Color.red);
                        return;
                    }

                    var itemAsset = (ItemAsset)asset;

                    var itemShop = new ItemShop(id, itemAsset.itemName, cost, buyback);

                    Plugin.DataBase.AddObject(itemShop);

                    UnturnedChat.Say(caller, Plugin.Instance.Translate("add_item", itemAsset.id, itemAsset.itemName, cost, buyback), Color.yellow);
                    return;
                }
                else
                {
                    var asset = Assets.find(EAssetType.VEHICLE, id);

                    if (asset == null)
                    {
                        UnturnedChat.Say(caller, Plugin.Instance.Translate("vehicle_asset_null"), Color.red);
                        return;
                    }

                    var vehicleAsset = (VehicleAsset)asset;

                    var vehicleShop = new VehicleShop(id, vehicleAsset.vehicleName, cost);

                    Plugin.DataBase.AddObject(vehicleShop);

                    UnturnedChat.Say(caller, Plugin.Instance.Translate("add_vehicle", vehicleAsset.id, vehicleAsset.name, cost), Color.yellow);
                }
            }
        }
    }
}

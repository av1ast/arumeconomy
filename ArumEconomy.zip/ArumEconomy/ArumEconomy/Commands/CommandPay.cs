﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Chat;
using ArumEconomy.Types;
using UnityEngine;
using Rocket.Unturned.Player;

namespace ArumEconomy.Commands
{
    class CommandPay : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;

        public string Name => "pay";

        public string Help => "";

        public string Syntax => "/pay [otherPlayer] [sum]";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.pay" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;
            if (command.Length != 2 && command.Length != 0)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            if (command.Length == 0)
            {
                player.SendUIPanel(ETypePanel.Pay);
                return;
            }
            if (command.Length == 2)
            {
                UnturnedPlayer targetPlayer = UnturnedPlayer.FromName(command[0]);

                PlayerShop playerShop = (PlayerShop)Plugin.DataBase.GetObjectShop<PlayerShop>(player.CSteamID.ToString());

                if (targetPlayer == null)
                {
                    UnturnedChat.Say(player, Plugin.Instance.Translate("player_not_found"), Color.red);
                    return;
                }

                if (!decimal.TryParse(command[1], out decimal sum) || sum < 1)
                {
                    UnturnedChat.Say(player, Plugin.Instance.Translate("incorrect_sum"), Color.red);
                    return;
                }

                if (playerShop.Balance < sum)
                {
                    UnturnedChat.Say(player, Plugin.Instance.Translate("dont_have_money"), Color.red);
                    return;
                }

                if (player.CSteamID.ToString() == targetPlayer.CSteamID.ToString())
                {
                    player.SendUIError(Plugin.Instance.Translate("cant_pay_hitself"));
                    return;
                }

                UnturnedChat.Say(player, Plugin.Instance.Translate("set_balance", targetPlayer.DisplayName, sum, Plugin.Instance.Configuration.Instance.NameEconomy), Color.yellow);
                UnturnedChat.Say(targetPlayer, Plugin.Instance.Translate("pay_balance", player.DisplayName, sum, Plugin.Instance.Configuration.Instance.NameEconomy), Color.yellow);
                Plugin.DataBase.SetBalance(player, sum, true);
                Plugin.DataBase.SetBalance(targetPlayer, sum);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Chat;
using ArumEconomy.Types;
using UnityEngine;
using Rocket.Unturned.Player;
using Rocket.Unturned.Items;
using SDG.Unturned;

namespace ArumEconomy.Commands
{
    class CommandBuyV : IRocketCommand
    {
        public AllowedCaller AllowedCaller => AllowedCaller.Player;

        public string Name => "buyv";

        public string Help => "";

        public string Syntax => "/buyv [vehicleID]";

        public List<string> Aliases => new List<string>();

        public List<string> Permissions => new List<string> { "command.buyv" };

        public void Execute(IRocketPlayer caller, string[] command)
        {
            UnturnedPlayer player = (UnturnedPlayer)caller;
            if (command.Length == 0)
            {
                player.SendUIPanel(ETypePanel.BuyV);
                return;
            }
            ushort VehicleID = 0;
            if (command.Length > 1)
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("syntax", Syntax), Color.red);
                return;
            }

            if (!ushort.TryParse(command[0], out VehicleID))
            {
                UnturnedChat.Say(player, Plugin.Instance.Translate("incorrect_id"), Color.red);
                return;
            }
            player.BuyVehicle(VehicleID);
        }
    }
}

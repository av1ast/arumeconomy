﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using SDG.Unturned;
using Rocket.Unturned.Player;
using ArumEconomy.Types;
using Rocket.Unturned.Items;
using Rocket.Unturned.Chat;

namespace ArumEconomy
{
    public class StorageSell
    {
        private Transform Transform { get; set; }
        internal InteractableStorage Storage { get; set; }
        internal UnturnedPlayer Player { get; set; }
        internal bool WasOpen { get; set; }
        internal byte[] State { get; set; }
        internal byte Height { get; set; }
        internal byte Width { get; set; }
        public StorageSell(UnturnedPlayer Player, byte Height, byte Width)
        {
            this.Player = Player;
            this.Height = Height;
            this.Width = Width;

            Transform = BarricadeTool.getBarricade(default, 100, Vector3.zero, default, 328, State);
            Storage = Transform.GetComponent<InteractableStorage>();
            WasOpen = false;
            Storage.items.onStateUpdated = new StateUpdated(OnVaultUpdate);
        }

        private void OnVaultUpdate()
        {
            if (Storage.items == null) return;
            SteamPacker.openWrite(0);
            SteamPacker.write(Player.CSteamID, Player.SteamGroupID, Storage.items.getItemCount());
            for (byte i = 0; i < Storage.items.getItemCount(); i++)
            {
                ItemJar itemJar = Storage.items.getItem(i);
                SteamPacker.write(itemJar.x, itemJar.y, itemJar.rot, itemJar.item.id, itemJar.item.amount, itemJar.item.quality, itemJar.item.state);
            }
            if (Storage.isDisplay)
            {
                SteamPacker.write(Storage.displaySkin);
                SteamPacker.write(Storage.displayMythic);
                SteamPacker.write((!string.IsNullOrEmpty(Storage.displayTags)) ? Storage.displayTags : string.Empty);
                SteamPacker.write((!string.IsNullOrEmpty(Storage.displayDynamicProps)) ? Storage.displayDynamicProps : string.Empty);
                SteamPacker.write(Storage.rot_comp);
            }
            byte[] thisState = SteamPacker.closeWrite(out int size);
            State = new byte[size];
            Array.Copy(thisState, State, size);
        }

        public void CloseStorage()
        {
            try
            {
                if (Storage.opener != null)
                {
                    Storage.opener.inventory.isStorageTrunk = false;
                    Storage.opener.inventory.isStoring = false;
                    Storage.opener.inventory.storage = null;
                    Storage.opener = null;
                    Storage.opener.inventory.updateItems(PlayerInventory.STORAGE, null);
                    Storage.opener.inventory.sendStorage();
                }
                WasOpen = false;
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex, "Exception in CloseStorage"); }
        }

        public void Clear()
        {
            try
            {
                if (Storage != null)
                {
                    CloseStorage();
                    Storage.transform.position = Vector3.zero;
                    if (Storage.items != null && Storage.items.getItemCount() > 0) Storage.items.clear();

                    UnityEngine.Object.Destroy(Storage.transform.gameObject);
                    Storage = null;
                }
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex, "Exception in Clear"); }
        }

        public void SendStorage()
        {
            try
            {
                Storage.transform.position = Player.Position + Vector3.down;
                Storage.items.resize(Width, Height);
                if (Storage == null) return;
                if (Player.Player.inventory.isStorageTrunk || Player.Player.inventory.isStoring)
                {
                    Player.Player.inventory.isStorageTrunk = false;
                    Player.Player.inventory.isStoring = false;
                    Player.Player.inventory.storage = null;
                    Player.Player.inventory.updateItems(PlayerInventory.STORAGE, null);
                    Player.Player.inventory.sendStorage();
                }
                Storage.opener = Player.Player;
                Player.Player.inventory.isStoring = true;
                Player.Player.inventory.isStorageTrunk = false;
                WasOpen = true;
                Player.Player.inventory.storage = Storage;
                Player.Player.inventory.updateItems(PlayerInventory.STORAGE, Storage.items);
                Player.Player.inventory.sendStorage();
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex, "Exception in SendStorage"); }
        }

        public void SellItems()
        {
            if (Storage.items.getItemCount() != 0)
            {
                decimal sum = 0;

                foreach (ItemJar jar in Storage.items.items)
                {
                    ItemShop itemFromShop = (ItemShop)Plugin.DataBase.GetObjectShop<ItemShop>(jar.item.id);
                    if (itemFromShop == null || itemFromShop.BuyBack == 0)
                    {
                        Player.Player.inventory.forceAddItem(jar.item, true);
                        continue;
                    }
                    decimal cost = itemFromShop.BuyBack;
                    if (UnturnedItems.GetItemAssetById(itemFromShop.ItemID).type == EItemType.MAGAZINE)
                    {
                        cost = cost / UnturnedItems.GetItemAssetById(itemFromShop.ItemID).amount * jar.item.amount;
                    }
                    sum += cost;
                }
                Plugin.DataBase.SetBalance(Player, sum);
                UnturnedChat.Say(Player, Plugin.Instance.Translate("sells", System.Math.Round(sum, 2), Plugin.Instance.Configuration.Instance.NameEconomy), Color.yellow);
            }
        }
    }
}

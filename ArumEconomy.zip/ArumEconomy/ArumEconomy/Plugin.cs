﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.API;
using Rocket.Unturned.Player;
using Rocket.Core.Plugins;
using Rocket.Unturned.Chat;
using SDG.Unturned;
using UnityEngine;
using Rocket.API.Collections;
using ArumEconomy.Types;
using Rocket.Unturned;
using ArumEconomy.Components;
using Rocket.Unturned.Events;
using Rocket.Unturned.Items;

namespace ArumEconomy
{
    public class Plugin : RocketPlugin<Config>
    {
        public override TranslationList DefaultTranslations => new TranslationList
        {
            { "syntax", "Используйте данный синтаксис: {0}" },
            { "sells", "Вы продали вещей на [{0}]{1}" },
            { "ui_balance", "{0}$" },
            { "ui_update_balance", "{0}{1}$" },
            { "enabled_ui_balance", "Вы включили отображение вашего баланса" },
            { "disabled_ui_balance", "Вы включили отображение вашего баланса" },
            { "balance", "Ваш баланс составляет: [{0}]{1}." },
            { "player_not_found", "Данный игрок не найден." },
            { "incorrect_sum", "Некорректно введена сумма." },
            { "set_balance", "Вы перевели игрооку: [{0}] [{1}]{2}." },
            { "pay_balance", "Игрок: [{0}] перевел вам: [{1}]{2}." },
            { "item_not_found", "Данный предмет не продается." },
            { "dont_have_money", "У вас недостаточно средств." },
            { "buy", "Вы купили [{0}/{1}] x{2}" },
            { "vehicle_not_found", "Данный авто не продается." },
            { "incorrect_amount", "Некорректно введёно кол-во." },
            { "incorrect_id", "Некорректно введён VehicleID." },
            { "online_pay", "Вы получили: [{0}]{1} за проигранные [{2}] минут." },
            { "itemid", "ItemID: {0}" },
            { "itemname", "ItemName: {0}" },
            { "cost", "Цена: {0}{1}" },
            { "buyback", "Цена продажи: {0}{1}" },
            { "cant_pay_hitself", "Вы не можете перевести самому себе" },
            { "you_win", "Поздравляем! Вы приумножили свой баланс. Выигрыш: [{0}]{1}" },
            { "you_lose", "Вы проиграли =( Не теряйте надежд!" },
            { "cant_because_you_in_the_car", "Вы не можете продавать вещи находясь в автомобиле" },
            { "incorrect_cost", "Некорректно введён Cost" },
            { "incorrect_buyback", "Некорректно введён Buyback" },
            { "add_item", "Вы добавили/обновили Item в магазин: [{0}/{1}], цена покупки: [{2}], цена продажи: [{3}]." },
            { "incorrect_id", "Неверно введён ItemId или VehicleId" },
            { "item_asset_null", "Не удалось получить ItemAsset данного предмета. Возможно, он отсутствует." },
            { "add_vehicle", "Вы добавили/обновили Vehicle в магазин: [{0}/{1}], цена покупки: [{2}]." },
            { "vehicle_asset_null", "Не удалось получить VehicleAsset данного ТС. Возможно, он отсутствует." },
            { "itemshop_null", "Предмет с таким Id не найден в товарах магазина." },
            { "delete_itemshop", "Вы удалили предмет: [{0}/{1}] с магазина." },
            { "vehicleshop_null", "ТС с таким Id не найден в товарах магазина." },
            { "delete_vehicleshop", "Вы удалили ТС: [{0}/{1}] с магазина." }
        };

        public static Plugin Instance;
        public static DataBase DataBase;
        protected override void Load()
        {
            Instance = this;
            DataBase = new DataBase();
            if (Configuration.Instance.DownloadWorkshop) WorkshopDownloadConfig.getOrLoad().File_IDs.Add(1996842899);
            DataBase.OnUpdateBalance += DataBase_OnUpdateBalance;
            U.Events.OnPlayerConnected += Events_OnPlayerConnected;
            UnturnedPlayerEvents.OnPlayerUpdateStat += UnturnedPlayerEvents_OnPlayerUpdateStat;
            EffectManager.onEffectButtonClicked += OnClicked;
            EffectManager.onEffectTextCommitted += OnTextCommited;
            UnturnedPlayerEvents.OnPlayerDeath += UnturnedPlayerEvents_OnPlayerDeath;
        }

        private void UnturnedPlayerEvents_OnPlayerDeath(UnturnedPlayer player, EDeathCause cause, ELimb limb, Steamworks.CSteamID murderer)
        {
            UnturnedPlayer killer = UnturnedPlayer.FromCSteamID(murderer);
            try
            {
                if (cause == EDeathCause.SUICIDE || cause == EDeathCause.ROADKILL || cause == EDeathCause.GUN || cause == EDeathCause.GRENADE || cause == EDeathCause.PUNCH || cause == EDeathCause.MELEE)
                {

                    PlayerShop playerShop = (PlayerShop)DataBase.GetObjectShop<PlayerShop>(player.CSteamID.ToString());
                    if (playerShop.Balance > 0)
                    {
                        if (Configuration.Instance.AccrualBalance.DeathPlayer > playerShop.Balance)
                        {
                            DataBase.SetBalance(player, playerShop.Balance, true);
                            return;
                        }
                        DataBase.SetBalance(player, Configuration.Instance.AccrualBalance.DeathPlayer, true);
                    }
                    if (cause != EDeathCause.SUICIDE)
                        DataBase.SetBalance(killer, Configuration.Instance.AccrualBalance.KillPlayer);
                }
            }
            catch (Exception ex) { Rocket.Core.Logging.Logger.LogException(ex); }
        }

        private void OnTextCommited(Player UPlayer, string buttonName, string text)
        {
            UnturnedPlayer player = UnturnedPlayer.FromPlayer(UPlayer);
            ShopComponent shopComponent = player.GetComponent<ShopComponent>();

            switch (buttonName)
            {
                case "arum.economy.item":
                    shopComponent.Item = text;
                    ItemAsset itemAsset = UnturnedItems.GetItemAssetByName(text);
                    if (itemAsset == null && ushort.TryParse(text, out ushort ItemID)) itemAsset = UnturnedItems.GetItemAssetById(ItemID); 
                    if (itemAsset == null) player.SendBuyPanel(null);
                    else player.SendBuyPanel(DataBase.GetObjectShop<ItemShop>(itemAsset.id));
                    break;
                case "arum.economy.amount":
                    if (!byte.TryParse(text, out byte amount))
                    {
                        player.SendUIError(Translate("incorrect_amount"));
                        return;
                    }
                    shopComponent.Amount = amount;
                    break;
                case "arum.economy.vehicle":
                    shopComponent.Vehicle = text;
                    VehicleAsset vehicleAsset = (VehicleAsset)Assets.find(EAssetType.VEHICLE, text);
                    if (vehicleAsset == null && ushort.TryParse(text, out ushort VehicleID)) vehicleAsset = (VehicleAsset)Assets.find(EAssetType.VEHICLE, VehicleID);
                    if (vehicleAsset == null) player.SendBuyVPanel(null);
                    else player.SendBuyVPanel(DataBase.GetObjectShop<VehicleShop>(vehicleAsset.id));
                    break;
                case "arum.economy.player":
                    shopComponent.targetPlayer = text;
                    break;
                case "arum.economy.sum":
                    shopComponent.Sum = decimal.Parse(text);
                    break;
            }
        }

        private void OnClicked(Player UPlayer, string buttonName)
        {
            UnturnedPlayer player = UnturnedPlayer.FromPlayer(UPlayer);
            ShopComponent shopComponent = player.GetComponent<ShopComponent>();

            switch (buttonName)
            {
                case "arum.economy.close":
                    player.CloseUIPanel();
                    break;
                case "arum.economy.playerpay":
                    PlayerShop playerShop = (PlayerShop)DataBase.GetObjectShop<PlayerShop>(player.CSteamID.ToString());

                    UnturnedPlayer targetPlayer = UnturnedPlayer.FromName(shopComponent.targetPlayer);

                    if (targetPlayer == null)
                    {
                        player.SendUIError(Translate("player_not_found"));
                        return;
                    }

                    if (shopComponent.Sum < 1)
                    {
                        player.SendUIError(Translate("incorrect_sum"));
                        return;
                    }
                    if (playerShop.Balance < shopComponent.Sum)
                    {
                        player.SendUIError(Translate("dont_have_money"));
                        return;
                    }

                    if (player.CSteamID.ToString() == targetPlayer.CSteamID.ToString())
                    {
                        player.SendUIError(Translate("cant_pay_hitself"));
                        return;
                    }

                    UnturnedChat.Say(player, Translate("set_balance", targetPlayer.DisplayName, shopComponent.Sum, Configuration.Instance.NameEconomy), Color.yellow);
                    UnturnedChat.Say(targetPlayer, Translate("pay_balance", player.DisplayName, shopComponent.Sum, Configuration.Instance.NameEconomy), Color.yellow);
                    DataBase.SetBalance(player, shopComponent.Sum, true);
                    DataBase.SetBalance(targetPlayer, shopComponent.Sum);
                    player.CloseUIPanel();
                    break;
                case "arum.economy.playerbuy":
                    if (shopComponent.Item == null) return;
                    ItemAsset itemAsset = UnturnedItems.GetItemAssetByName(shopComponent.Item);
                    if (itemAsset == null && ushort.TryParse(shopComponent.Item, out ushort ItemID)) itemAsset = UnturnedItems.GetItemAssetById(ItemID);
                    if (itemAsset == null)
                    {
                        player.SendUIError(Translate("item_not_found"));
                        return;
                    }
                    player.BuyItem(itemAsset.id, shopComponent.Amount, true);
                    break;
                case "arum.economy.playerbuyv":
                    VehicleAsset vehicleAsset = (VehicleAsset)Assets.find(EAssetType.VEHICLE, shopComponent.Vehicle);
                    if (vehicleAsset == null && ushort.TryParse(shopComponent.Vehicle, out ushort VehicleID)) vehicleAsset = (VehicleAsset)Assets.find(EAssetType.VEHICLE, VehicleID);
                    if (vehicleAsset == null)
                    {
                        player.SendUIError(Translate("vehicle_not_found"));
                        return;
                    }
                    player.BuyVehicle(vehicleAsset.id, true);
                    break;
            }
        }

        private void UnturnedPlayerEvents_OnPlayerUpdateStat(UnturnedPlayer player, EPlayerStat stat)
        {
            switch (stat)
            {
                case EPlayerStat.KILLS_ZOMBIES_NORMAL:
                    if (DateTime.Now.IsNight())
                        DataBase.SetBalance(player, Configuration.Instance.AccrualBalance.KillZombieNight);
                    else
                        DataBase.SetBalance(player, Configuration.Instance.AccrualBalance.KillZombie);
                    break;
                case EPlayerStat.KILLS_ZOMBIES_MEGA:
                    if (DateTime.Now.IsNight())
                        DataBase.SetBalance(player, Configuration.Instance.AccrualBalance.KillMegaZombieNight);
                    else
                        DataBase.SetBalance(player, Configuration.Instance.AccrualBalance.KillMegaZombie);
                    break;
                /*case EPlayerStat.KILLS_PLAYERS:
                    if (player.Dead)
                    {
                        DataBase.SetBalance(player, Configuration.Instance.AccrualBalance.DeathPlayer, true);
                        return;
                    }
                    DataBase.SetBalance(player, Configuration.Instance.AccrualBalance.KillPlayer);
                    break;
                case EPlayerStat.DEATHS_PLAYERS:
                    DataBase.SetBalance(player, Configuration.Instance.AccrualBalance.DeathPlayer, true);
                    break;*/
            }
        }

        private void DataBase_OnUpdateBalance(UnturnedPlayer player, char type, decimal sum)
        {
            if (player.GetComponent<ShopComponent>().EnabledUI)
            {
                player.SendUIBalance();
                player.SendUIUpdateBalance(type, sum);
            }
        }

        private void Events_OnPlayerConnected(UnturnedPlayer player)
        {
            if (DataBase.GetObjectShop<PlayerShop>(player.CSteamID.m_SteamID) == null)
                DataBase.AddObject(new PlayerShop(player.CSteamID.ToString(), Configuration.Instance.StartBalance, DateTime.Now));
            else
                DataBase.UpdatePlayer(player);
            player.SendUIBalance();
        }

        protected override void Unload()
        {
            DataBase.OnUpdateBalance -= DataBase_OnUpdateBalance;
            U.Events.OnPlayerConnected -= Events_OnPlayerConnected;
            UnturnedPlayerEvents.OnPlayerUpdateStat -= UnturnedPlayerEvents_OnPlayerUpdateStat;
            UnturnedPlayerEvents.OnPlayerDeath -= UnturnedPlayerEvents_OnPlayerDeath;
            EffectManager.onEffectButtonClicked -= OnClicked;
            EffectManager.onEffectTextCommitted -= OnTextCommited;
        }
    }
}

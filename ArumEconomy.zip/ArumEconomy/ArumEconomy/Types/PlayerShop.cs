﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArumEconomy.Types
{
    public class PlayerShop
    {
        public string SteamID64;
        public decimal Balance;
        public DateTime LastUpdate;
        public PlayerShop(string SteamID64, decimal Balance, DateTime LastUpdate)
        {
            this.SteamID64 = SteamID64;
            this.Balance = Balance;
            this.LastUpdate = LastUpdate;
        }
        public PlayerShop() { }
    }
}

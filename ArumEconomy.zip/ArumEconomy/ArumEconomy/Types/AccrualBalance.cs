﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArumEconomy.Types
{
    public class AccrualBalance
    {
        public bool EnabledNightTraffic;
        public decimal KillPlayer, DeathPlayer, KillZombie, KillZombieNight, KillMegaZombie, KillMegaZombieNight;
        public byte NightDiscount;
        public List<OnlineSettings> OnlineSettings;
        public AccrualBalance(bool EnabledNightTraffic, decimal KillPlayer, decimal DeathPlayer, decimal KillZombie, decimal KillZombieNight, decimal KillMegaZombie, decimal KillMegaZombieNight, byte NightDiscount, List<OnlineSettings> OnlineSettings)
        {
            this.EnabledNightTraffic = EnabledNightTraffic;
            this.KillPlayer = KillPlayer;
            this.DeathPlayer = DeathPlayer;
            this.KillZombie = KillZombie;
            this.KillZombieNight = KillZombieNight;
            this.KillMegaZombie = KillMegaZombie;
            this.KillMegaZombieNight = KillMegaZombieNight;
            this.NightDiscount = NightDiscount;
            this.OnlineSettings = OnlineSettings;
        }
        public AccrualBalance() { }
    }
}

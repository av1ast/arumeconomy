﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ArumEconomy.Types
{
    public class DiscountGroup
    {
        [XmlAttribute]
        public string GroupID;
        [XmlAttribute]
        public byte Discount;
        public DiscountGroup(string GroupID, byte Discount)
        {
            this.GroupID = GroupID;
            this.Discount = Discount;
        }
        public DiscountGroup() { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ArumEconomy.Types
{
    public class MySqlSettings
    {
        [XmlAttribute]
        public string Host, Port, UserName, Password, DataBase, TablePlayers, TableVehicles, TableItems;
        public MySqlSettings(string Host, string Port, string UserName, string Password, string DataBase, string TablePlayers, string TableVehicles, string TableItems)
        {
            this.Host = Host;
            this.Port = Port;
            this.UserName = UserName;
            this.Password = Password;
            this.DataBase = DataBase;
            this.TablePlayers = TablePlayers;
            this.TableVehicles = TableVehicles;
            this.TableItems = TableItems;
        }
        public MySqlSettings() { }
    }
}

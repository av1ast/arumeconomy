﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArumEconomy.Types
{
    public class ItemShop
    {
        public ushort ItemID;
        public string Name;
        public decimal Cost;
        public decimal BuyBack;
        public ItemShop(ushort ItemID, string Name, decimal Cost, decimal BuyBack)
        {
            this.ItemID = ItemID;
            this.Name = Name;
            this.Cost = Cost;
            this.BuyBack = BuyBack;
        }
        public ItemShop() { }
    }
}

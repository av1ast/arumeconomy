﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArumEconomy.Types
{
    public enum ETypePanel
    {
        Pay,
        Buy,
        BuyV,
    };
}

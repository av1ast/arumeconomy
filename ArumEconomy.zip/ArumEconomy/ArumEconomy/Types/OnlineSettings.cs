﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ArumEconomy.Types
{
    public class OnlineSettings
    {
        [XmlAttribute]
        public string GroupID;
        [XmlAttribute]
        public decimal Sum, NightTrafficSum;
        public OnlineSettings(string GroupID, decimal Sum, decimal NightTrafficSum)
        {
            this.GroupID = GroupID;
            this.Sum = Sum;
            this.NightTrafficSum = NightTrafficSum;
        }
        public OnlineSettings() { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ArumEconomy.Types
{
    public class SellSettings
    {
        [XmlAttribute]
        public string GroupID;
        [XmlAttribute]
        public byte Height, Width;
        public SellSettings(string GroupID, byte Height, byte Width)
        {
            this.GroupID = GroupID;
            this.Height = Height;
            this.Width = Width;
        }
        public SellSettings() { }
    }
}

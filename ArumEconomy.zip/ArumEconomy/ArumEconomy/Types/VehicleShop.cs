﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArumEconomy.Types
{
    public class VehicleShop
    {
        public ushort VehicleID;
        public string Name;
        public decimal Cost;
        public VehicleShop(ushort VehicleID, string Name, decimal Cost)
        {
            this.VehicleID = VehicleID;
            this.Name = Name;
            this.Cost = Cost;
        }
        public VehicleShop() { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArumEconomy.Types;
using Rocket.API;

namespace ArumEconomy
{
    public class Config : IRocketPluginConfiguration
    {
        public bool DownloadWorkshop;
        public string NameEconomy;
        public decimal StartBalance;
        public ushort Effect_1;
        public short Effect_1_Key;
        public ushort Effect_2;
        public short Effect_2_Key;
        public ushort Effect_3;
        public short Effect_3_Key;
        public int MinutesOnline;
        public byte StartNight;
        public byte EndNight;
        public List<DiscountGroup> DiscountGroups;
        public AccrualBalance AccrualBalance;
        public List<SellSettings> SellSettings;
        public MySqlSettings MySqlSettings;
        public void LoadDefaults()
        {
            DownloadWorkshop = true;
            NameEconomy = "$";
            StartBalance = 250m;
            Effect_1 = 8694;
            Effect_1_Key = 8694;
            Effect_2 = 8695;
            Effect_2_Key = 8695;
            Effect_3 = 9854;
            Effect_3_Key = 9854;
            MinutesOnline = 20;
            StartNight = 22;
            EndNight = 8;
            DiscountGroups = new List<DiscountGroup>
            {
                new DiscountGroup("default", 0),
                new DiscountGroup("vip", 25),
            };
            AccrualBalance = new AccrualBalance(true, 50.0m, 75.0m, 15.0m, 30.0m, 400.0m, 800.0m, 15, new List<OnlineSettings>
            {
                new OnlineSettings("default", 50.0m, 100.0m),
                new OnlineSettings("vip", 100.0m, 200.0m),
            });
            SellSettings = new List<SellSettings>
            {
                new SellSettings("default", 5, 5),
                new SellSettings("vip", 10, 10)
            };
            MySqlSettings = new MySqlSettings("localhost", "3306", "root", "root", "unturned", "economy_players", "economy_vehicles", "economy_items");
        }
    }
}

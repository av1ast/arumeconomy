﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArumEconomy.Types;
using Rocket.Unturned.Chat;
using Rocket.Unturned.Player;
using UnityEngine;

namespace ArumEconomy.Components
{
    class ShopComponent : UnturnedPlayerComponent
    {
        public bool EnabledUI;
        public string targetPlayer;
        public decimal Sum;
        //
        public string Item;
        public byte Amount;
        //
        public string Vehicle;
        //
        private DateTime TimeConnect;
        protected override void Load()
        {
            EnabledUI = true;
            targetPlayer = null;
            Sum = 0;
            Item = null;
            Vehicle = null;
            Amount = 1;
            TimeConnect = DateTime.Now;
        }

        public void ResetComponent()
        {
            targetPlayer = null;
            Sum = 0;
            Item = null;
            Vehicle = null;
            Amount = 1;
        }

        public void Update()
        {
            if ((DateTime.Now - TimeConnect).TotalMinutes >= Plugin.Instance.Configuration.Instance.MinutesOnline)
            {
                OnlineSettings onlineSettings = Player.GetOnlineSettings();
                if (DateTime.Now.IsNight()) Plugin.DataBase.SetBalance(Player, onlineSettings.NightTrafficSum);
                else Plugin.DataBase.SetBalance(Player, onlineSettings.Sum);
                UnturnedChat.Say(Player, Plugin.Instance.Translate("online_pay", DateTime.Now.IsNight() ? onlineSettings.NightTrafficSum : onlineSettings.Sum, Plugin.Instance.Configuration.Instance.NameEconomy, Plugin.Instance.Configuration.Instance.MinutesOnline), Color.yellow);
                TimeConnect = DateTime.Now;
            }
        }
    }
}

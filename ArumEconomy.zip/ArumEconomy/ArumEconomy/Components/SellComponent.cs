﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rocket.Unturned.Player;

namespace ArumEconomy.Components
{
    class SellComponent : UnturnedPlayerComponent
    {
        public StorageSell Seller;

        protected override void Load()
        {
            Seller = null;
        }

        public void Update()
        {
            try
            {
                if (Seller != null && Seller.WasOpen)
                {
                    if (!Player.Player.inventory.isStoring)
                    {
                        Seller.SellItems();
                        Seller.Clear();
                        Seller = null;
                    }

                    if (Player.IsInVehicle && (Player.CurrentVehicle != null && Player.CurrentVehicle.checkDriver(Player.CSteamID)))
                    {
                        Player.Player.inventory.closeStorage();
                        Seller.Clear();
                        Seller = null;
                    }
                }
            } 
            catch (Exception) { }
        }
    }
}

﻿using ArumEconomy.Components;
using ArumEconomy.Types;
using Rocket.API.Serialisation;
using Rocket.Core;
using Rocket.Unturned.Chat;
using Rocket.Unturned.Items;
using Rocket.Unturned.Player;
using SDG.Unturned;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using UnityEngine;

namespace ArumEconomy
{
    public static class Main
    {
        /// <summary>
        /// Получение размера Sell контейнера
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        public static SellSettings GetSellSettings(this UnturnedPlayer player)
        {
            foreach (SellSettings settings in Plugin.Instance.Configuration.Instance.SellSettings)
            {
                foreach (RocketPermissionsGroup group in R.Permissions.GetGroups(player, false))
                {
                    if (settings.GroupID.ToLower() == group.Id.ToLower()) return settings;
                }
            }
            return null;
        }
        /// <summary>
        /// Отображение UI баланса игроку
        /// </summary>
        /// <param name="player"></param>
        public static void SendUIBalance(this UnturnedPlayer player)
        {
            PlayerShop playerShop = (PlayerShop)Plugin.DataBase.GetObjectShop<PlayerShop>(player.CSteamID.ToString());
            EffectManager.sendUIEffect(Plugin.Instance.Configuration.Instance.Effect_1, Plugin.Instance.Configuration.Instance.Effect_1_Key, player.CSteamID, true, Plugin.Instance.Translate("ui_balance", playerShop.Balance));
        }
        /// <summary>
        /// Отображение UI обновления баланса
        /// </summary>
        /// <param name="player"></param>
        /// <param name="type"></param>
        /// <param name="sum"></param>
        public static void SendUIUpdateBalance(this UnturnedPlayer player, char type, decimal sum)
        {
            EffectManager.sendUIEffect(Plugin.Instance.Configuration.Instance.Effect_2, Plugin.Instance.Configuration.Instance.Effect_2_Key, player.CSteamID, true, Plugin.Instance.Translate("ui_update_balance", type, sum));
        }

        public static void CloseUIBalance(this UnturnedPlayer player)
        {
            EffectManager.askEffectClearByID(Plugin.Instance.Configuration.Instance.Effect_1, player.CSteamID);
        }

        public static OnlineSettings GetOnlineSettings(this UnturnedPlayer player)
        {
            foreach (OnlineSettings onlineSettings in Plugin.Instance.Configuration.Instance.AccrualBalance.OnlineSettings)
            {
                foreach (RocketPermissionsGroup group in R.Permissions.GetGroups(player, false))
                {
                    if (onlineSettings.GroupID.ToLower() == group.Id.ToLower()) return onlineSettings;
                }
            }
            return null;
        }

        public static bool IsNight(this DateTime time)
        {
            if (Plugin.Instance.Configuration.Instance.AccrualBalance.EnabledNightTraffic && (time.Hour > Plugin.Instance.Configuration.Instance.StartNight || time.Hour < Plugin.Instance.Configuration.Instance.EndNight))
                return true;
            return false;
        }

        public static void SendUIError(this UnturnedPlayer player, string message)
        {
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.pay.text", message);
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.buy.text", message);
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.buy.text", message);
        }

        public static void BuyItem(this UnturnedPlayer player, ushort itemID, byte Amount, bool fromPanel = false)
        {
            PlayerShop playerShop = (PlayerShop)Plugin.DataBase.GetObjectShop<PlayerShop>(player.CSteamID.ToString());
            ItemShop itemShop = (ItemShop)Plugin.DataBase.GetObjectShop<ItemShop>(itemID);

            if (itemShop == null || itemShop.Cost == 0)
            {
                if (fromPanel)
                {
                    player.SendUIError(Plugin.Instance.Translate("item_not_found"));
                    return;
                }
                UnturnedChat.Say(player, Plugin.Instance.Translate("item_not_found"), Color.red);
                return;
            }

            byte Discount = player.GetDiscount();


            if (IsNight(DateTime.Now)) Discount += Plugin.Instance.Configuration.Instance.AccrualBalance.NightDiscount;


            if (Discount > 100) Discount = 100;


            if (playerShop.Balance < (itemShop.Cost * Amount) && Discount == 0 || Discount != 0 && playerShop.Balance < itemShop.Cost * Amount * (100 - Discount) / 100)
            {
                if (fromPanel)
                {
                    player.SendUIError(Plugin.Instance.Translate("dont_have_money"));
                    return;
                }
                UnturnedChat.Say(player, Plugin.Instance.Translate("dont_have_money"), Color.red);
                return;
            }

            Plugin.DataBase.SetBalance(player, itemShop.Cost * Amount, true);
            UnturnedChat.Say(player, Plugin.Instance.Translate("buy", itemID, UnturnedItems.GetItemAssetById(itemID).itemName, Amount), Color.yellow);
            player.GiveItem(itemID, Amount);
        }

        public static void BuyVehicle(this UnturnedPlayer player, ushort vehicleID, bool fromPanel = false)
        {
            PlayerShop playerShop = (PlayerShop)Plugin.DataBase.GetObjectShop<PlayerShop>(player.CSteamID.ToString());
            VehicleShop vehicleShop = (VehicleShop)Plugin.DataBase.GetObjectShop<VehicleShop>(vehicleID);

            if (vehicleShop == null)
            {
                if (fromPanel)
                {
                    player.SendUIError(Plugin.Instance.Translate("vehicle_not_found"));
                    return;
                }
                UnturnedChat.Say(player, Plugin.Instance.Translate("vehicle_not_found"), Color.red);
                return;
            }

            byte Discount = player.GetDiscount();
            if (IsNight(DateTime.Now)) Discount += Plugin.Instance.Configuration.Instance.AccrualBalance.NightDiscount;
            if (Discount > 100) Discount = 100;
            if (playerShop.Balance < vehicleShop.Cost && Discount == 0 || Discount != 0 && playerShop.Balance < vehicleShop.Cost * (100 - Discount) / 100)
            {
                if (fromPanel)
                {
                    player.SendUIError(Plugin.Instance.Translate("dont_have_money"));
                    return;
                }
                UnturnedChat.Say(player, Plugin.Instance.Translate("dont_have_money"), Color.red);
                return;
            }
            Plugin.DataBase.SetBalance(player, vehicleShop.Cost, true);
            UnturnedChat.Say(player, Plugin.Instance.Translate("buy", vehicleID, ((VehicleAsset)Assets.find(EAssetType.VEHICLE, vehicleID)).vehicleName, "1"));
            player.GiveVehicle(vehicleID);
        }

        public static void SendUIPanel(this UnturnedPlayer player, ETypePanel panel)
        {
            EffectManager.sendUIEffect(Plugin.Instance.Configuration.Instance.Effect_3, Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true);
            player.Player.setPluginWidgetFlag(EPluginWidgetFlags.Modal, true);
            if (panel == ETypePanel.Buy) EffectManager.sendUIEffectVisibility(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.buy", true);
            else if (panel == ETypePanel.BuyV) EffectManager.sendUIEffectVisibility(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.buyv", true);
            else EffectManager.sendUIEffectVisibility(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.pay", true);
        }

        public static void SendBuyPanel(this UnturnedPlayer player, object itemShopObject)
        {
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.itemname", itemShopObject == null ? "" : Plugin.Instance.Translate("itemid", ((ItemShop)itemShopObject).ItemID));
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.itemid", itemShopObject == null ? "" : Plugin.Instance.Translate("itemname", UnturnedItems.GetItemAssetById(((ItemShop)itemShopObject).ItemID).itemName));
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.itemcost", itemShopObject == null ? "" : Plugin.Instance.Translate("cost", ((ItemShop)itemShopObject).Cost, Plugin.Instance.Configuration.Instance.NameEconomy));
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.itembuyback", itemShopObject == null ? "" : Plugin.Instance.Translate("buyback", ((ItemShop)itemShopObject).BuyBack, Plugin.Instance.Configuration.Instance.NameEconomy));
        }

        public static void SendBuyVPanel(this UnturnedPlayer player, object vehicleShopObject)
        {
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.vehiclename", vehicleShopObject == null ? "" : Plugin.Instance.Translate("itemid", ((VehicleShop)vehicleShopObject).VehicleID));
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.vehicleid", vehicleShopObject == null ? "" : Plugin.Instance.Translate("itemname", Assets.find(EAssetType.VEHICLE, ((VehicleShop)vehicleShopObject).VehicleID).name));
            EffectManager.sendUIEffectText(Plugin.Instance.Configuration.Instance.Effect_3_Key, player.CSteamID, true, "arum.economy.vehiclecost", vehicleShopObject == null ? "" : Plugin.Instance.Translate("cost", ((VehicleShop)vehicleShopObject).Cost, Plugin.Instance.Configuration.Instance.NameEconomy));
        }

        public static void CloseUIPanel(this UnturnedPlayer player)
        {
            player.GetComponent<ShopComponent>().ResetComponent();
            EffectManager.askEffectClearByID(Plugin.Instance.Configuration.Instance.Effect_3, player.CSteamID);
            player.Player.setPluginWidgetFlag(EPluginWidgetFlags.Modal, false);
        }

        public static byte GetDiscount(this UnturnedPlayer player)
        {
            foreach (DiscountGroup discount in Plugin.Instance.Configuration.Instance.DiscountGroups)
            {
                foreach (RocketPermissionsGroup group in R.Permissions.GetGroups(player, true))
                {
                    if (discount.GroupID.ToLower() == group.Id.ToLower()) return discount.Discount;
                }
            }
            return 0;
        }
    }
}
